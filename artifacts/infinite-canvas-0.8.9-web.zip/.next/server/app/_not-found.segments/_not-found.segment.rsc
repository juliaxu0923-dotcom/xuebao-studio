1:"$Sreact.fragment"
2:I[339756,["/_next/static/chunks/1_tj89_8ipyt2.js","/_next/static/chunks/1lsphwdyvvz6r.js","/_next/static/chunks/113i07oh_2p4w.js","/_next/static/chunks/1hqr1a4_7mky4.js","/_next/static/chunks/2-9niha4htbmo.js","/_next/static/chunks/3e22v_wd_hqud.js","/_next/static/chunks/1ntn7efqc-iiw.js","/_next/static/chunks/058_ggwastlmq.js"],"default"]
3:I[837457,["/_next/static/chunks/1_tj89_8ipyt2.js","/_next/static/chunks/1lsphwdyvvz6r.js","/_next/static/chunks/113i07oh_2p4w.js","/_next/static/chunks/1hqr1a4_7mky4.js","/_next/static/chunks/2-9niha4htbmo.js","/_next/static/chunks/3e22v_wd_hqud.js","/_next/static/chunks/1ntn7efqc-iiw.js","/_next/static/chunks/058_ggwastlmq.js"],"default"]
4:[]
0:{"rsc":["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","template":["$","$L3",null,{}]}]]}],"isPartial":false,"staleTime":300,"varyParams":"$W4","buildId":"L4MBHXg1yJtKoKwM0l0LR"}
