1:"$Sreact.fragment"
3:I[897367,["/_next/static/chunks/1_tj89_8ipyt2.js","/_next/static/chunks/1lsphwdyvvz6r.js","/_next/static/chunks/113i07oh_2p4w.js","/_next/static/chunks/1hqr1a4_7mky4.js","/_next/static/chunks/2-9niha4htbmo.js","/_next/static/chunks/3e22v_wd_hqud.js","/_next/static/chunks/1ntn7efqc-iiw.js","/_next/static/chunks/058_ggwastlmq.js"],"OutletBoundary"]
4:"$Sreact.suspense"
0:{"rsc":["$","$1","c",{"children":["$L2",null,["$","$L3",null,{"children":["$","$4",null,{"name":"Next.MetadataOutlet","children":"$@5"}]}]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"L4MBHXg1yJtKoKwM0l0LR"}
5:null
2:E{"digest":"NEXT_REDIRECT;replace;/canvas;307;"}
