:HL["/_next/static/chunks/2yjbugow9h8yj.css","style"]
:HL["/_next/static/chunks/0awwy-2fr50mh.css","style"]
0:{"tree":{"name":"","param":null,"prefetchHints":16,"slots":{"children":{"name":"(admin)","param":null,"prefetchHints":0,"slots":{"children":{"name":"admin","param":null,"prefetchHints":0,"slots":{"children":{"name":"skills","param":null,"prefetchHints":0,"slots":{"children":{"name":"__PAGE__","param":null,"prefetchHints":0,"slots":null}}}}}}}}},"staleTime":300,"buildId":"L4MBHXg1yJtKoKwM0l0LR"}
