module.exports=[364597,a=>{"use strict";a.s([])}];

//# sourceMappingURL=_next-internal_server_app_%28admin%29_admin_page_actions_0-vl_61.js.map