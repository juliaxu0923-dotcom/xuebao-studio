module.exports=[384803,a=>{"use strict";a.s([])}];

//# sourceMappingURL=_next-internal_server_app_%28admin%29_admin_skills_page_actions_0yzx6k1.js.map